# Security Policy

## Supported Versions

The versions of the project that are currently supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 4.x | :white_check_mark: |
| 3.x | :white_check_mark: |
| < 3.0 | :x: |

## Reporting a Vulnerability

You can report a vulnerability by contacting us via email at [security@material-ui.com](mailto:security@material-ui.com).
