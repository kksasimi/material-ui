# 关于实验室

<p class="description">这个包还在开发中, 尚未准备好添加到核心库中</p>

## 安装

在你的项目中直接用以下命令安装:

```sh
// 用npm安装
npm install @material-ui/lab

// 用yarn安装
yarn add @material-ui/lab
```

该实验室对核心组件具有对等依赖性。 如果你尚未在你的项目中使用Material-UI, 你可以按如下方式安装:

```sh
// 用npm安装
npm install @material-ui/core

// 用yarn安装
yarn add @material-ui/core
```